--Task 9
--Download the data from https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBM-DB0260EN-SkillsNetwork/labs/Final%20Assignment/DimDate.csv
--Load this data into DimDate table.
SELECT * FROM DIMDATE LIMIT 5;

--Task 10
--Download the data from https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBM-DB0260EN-SkillsNetwork/labs/Final%20Assignment/DimTruck.csv
--Load this data into DimTruck table.
SELECT * FROM DIMTRUCK LIMIT 5;

--Task 11
--Download the data from https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBM-DB0260EN-SkillsNetwork/labs/Final%20Assignment/DimStation.csv
--Load this data into DimStation table.
SELECT * FROM DIMSTATION LIMIT 5;

--Task 12
--Download the data from https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBM-DB0260EN-SkillsNetwork/labs/Final%20Assignment/FactTrips.csv
--Load this data into FactTrips table.
SELECT * FROM FACTTRIPS LIMIT 5;



